
from setuptools import setup

from setuptools.command.install import install as _install


class Install(_install):
    """Class needed for install package
    """

    def run(self):
        """run installation"""
        _install.run(self)


setup(
    # Application name:
    name="behavex-web",

    # Version number (initial):
    version="1.3.4",
    # Application author details:
    author="Hernan Rey",
    author_email="hernanrey@gmail.com",
    url="",
    platforms=["any"],
    # Packages
    packages=["behavex_web",
              "behavex_web.steps",
              "behavex_web.utils",
              "behavex_web.utils.screenshots",
              "behavex_web.utils.screenshots.support_files"],

    # Include additional files into the package
    include_package_data=True,

    # license="LICENSE.txt",
    description="Basic robust web steps to interact with web pages",
    install_requires=["behaving==3.0.4",
                      "selenium",
                      "xvfbwrapper",
                      "lxml",
                      "numpy==1.24.2",
                      "pillow"],

    cmdclass={
        'install': Install
    },
)
