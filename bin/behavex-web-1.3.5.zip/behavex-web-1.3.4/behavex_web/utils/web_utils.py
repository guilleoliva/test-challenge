# -*- coding: utf-8 -*-
"""
///*
/* BehaveX
/*//

This module contains functions for performing
basic web related actions using Selenium WebDriver
Class:
    - WebUtils
        Properties;
           - driver
           - url
       Methods:
           - go_to
           - find_element
           - find_elements
           - find_element_by_id_not_button
           - find_element_by_id
           - find_elements_by_id
           - find_element_by_name
           - find_elements_by_name
           - find_element_by_xpath
           - find_elements_by_xpath
           - find_element_by_css_selector
           - find_elements_by_css_selector
           - find_element_by_link_text
"""
# pylint: disable=W0703
import logging
import selenium.webdriver.support.ui as ui
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as exp_cond
import time


class WebUtils(object):
    """Class containing core functions for interacting with web pages"""
    url = None

    def __init__(self, driver):
        self.driver = driver

    # pylint: disable=R0913
    def find_element(
            self, by_locator, locator, wait=1, retries=4,
            wait_for_clickable=True):
        """Retrieves the first element found in driver's current page
        based on a specified locator, considering retry intervals
        to properly deal with page loading times"""
        element = None
        if by_locator == By.LINK_TEXT:
            element = self.find_element_by_link_text(locator, wait, retries)
        elif by_locator == By.ID:
            element = self.find_element_by_id(
                locator, wait, retries, wait_for_clickable)
        elif by_locator == By.NAME:
            element = self.find_element_by_name(locator, wait, retries)
        elif by_locator == By.XPATH:
            element = self.find_element_by_xpath(locator, wait, retries)
        elif by_locator == By.CSS_SELECTOR:
            locator = locator.replace("\"", "'")\
                .replace("\'", "'")\
                .replace("\\'", "'")
            element = self.find_element_by_css_selector(locator, wait, retries)
        else:
            for i in range(retries):
                # noinspection PyBroadException
                try:
                    element = self.driver.find_element(by_locator, locator)
                    break
                except Exception:
                    if (i+1) == retries:
                        raise
        return element

    def find_elements(self, by_locator, locator, wait=1, retries=4):
        """Retrieves a list of all elements found in driver's current page
        based on a specified locator, considering retry intervals
        to properly deal with page loading times"""
        elements = None
        if by_locator == By.ID:
            elements = self.find_elements_by_id(locator, wait, retries)
        elif by_locator == By.NAME:
            elements = self.find_elements_by_name(locator, wait, retries)
        elif by_locator == By.XPATH:
            elements = self.find_elements_by_xpath(locator, wait, retries)
        elif by_locator == By.CSS_SELECTOR:
            locator = locator.replace("\"", "'")\
                .replace("\'", "'")\
                .replace("\\'", "'")
            elements = self.find_elements_by_css_selector(
                locator, wait, retries)
        else:
            for i in range(retries):
                try:
                    elements = self.driver.find_elements(by_locator, locator)
                    break
                except Exception as exception:
                    message = "Unable to find element with %s %s: '%s'." \
                              " Retry number: %s out of %s.\n%s"
                    logging.info(
                        message, by_locator, locator, str(i+1), str(retries),
                        exception)
                    if (i+1) == retries:
                        raise
        return elements

    def find_element_by_id_not_button(self, element_id, wait=2, retries=4):
        """Retrieves a web element using the ID locator.
        Retries are implemented to properly deal with page loading times"""
        elem = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                elem = wd_wait.until(
                    exp_cond.presence_of_element_located((By.ID, element_id)))
                break
            except Exception as exception:
                message = "Unable to find element with id: '%s'." \
                          " Retry number: %s out of %s.\nException:%s "
                logging.info(
                    message, element_id, str(i+1), str(retries), exception)
                if (i+1) == retries:
                    raise
        return elem

    def find_element_by_id(
            self, element_id, wait=2, retries=4, wait_for_clickable=True):
        """Retrieves a web element using the ID locator.
        Retries are implemented to properly deal with page loading times"""
        elem = None
        for i in range(retries):
            try:
                if wait_for_clickable:
                    wd_wait = ui.WebDriverWait(self.driver, int(wait))
                    # so it could still exist but if it isn't enabled- won't
                    # show :-/
                    elem = wd_wait.until(
                        exp_cond.element_to_be_clickable((By.ID, element_id)))
                else:
                    elem = self.driver.find_element(By.ID, element_id)
                break
            except Exception as exception:
                message = "Unable to find element with id: '%s'. " \
                          "Retry number: %s out of %s.\n%s"
                logging.info(
                    message, element_id, str(i+1), str(retries), exception)
                if (i+1) == retries:
                    raise
        return elem

    def find_elements_by_id(self, element_id, wait=1, retries=4):
        """Retrieves all web elements found using the ID locator.
        Retries are implemented to properly deal with page loading times"""
        elements = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                elements = wd_wait.until(
                    exp_cond.presence_of_all_elements_located(
                        (By.ID, element_id)))
                break
            except Exception as exception:
                message = "Unable to find elements with id: '%s'." \
                          " Retry number: %s out of %s.\n%s"
                logging.info(
                    message, element_id, str(i+1), str(retries), exception)
                if (i+1) == retries:
                    raise
        return elements

    def find_element_by_name(self, name, wait=1, retries=4):
        """Retrieves a web element using the NAME locator.
        Retries are implemented to properly deal with page loading times"""
        elem = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                elem = wd_wait.until(
                    exp_cond.element_to_be_clickable((By.NAME, name)))
                break
            except Exception as exception:
                message = "Unable to find element with name: '%s'." \
                          " Retry number: %s out of %s.\n%s"
                logging.info(
                    message, name, str(i+1), str(retries), exception)
                if (i+1) == retries:
                    raise
        return elem

    def find_elements_by_name(self, name, wait=1, retries=4):
        """Retrieves all web elements found using the NAME locator.
        Retries are implemented to properly deal with page loading times"""
        elements = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                elements = wd_wait.until(
                    exp_cond.presence_of_all_elements_located((By.NAME, name)))
                break
            except Exception as exception:
                message = "Unable to find elements with name: '%s'." \
                          " Retry number: %s out of %s.\n%s"
                logging.info(
                    message, name, str(i+1), str(retries), exception)
                if (i+1) == retries:
                    raise
        return elements

    def find_element_by_xpath(self, xpath, wait=10, retries=4):
        """Retrieves a web element using the XPATH locator.
        Retries are implemented to properly deal with page loading times"""
        elem = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                elem = wd_wait.until(
                    exp_cond.element_to_be_clickable((By.XPATH, xpath)))
                break
            except Exception as exception:
                message = "Unable to find element with xpath: '%s'. " \
                          "Retry number: %s out of %s.\n%s"
                logging.info(
                    message, xpath.encode('utf8'), str(i+1), str(retries),
                    exception)
                if (i+1) == retries:
                    raise
        return elem

    def find_elements_by_xpath(self, xpath, wait=1, retries=4):
        """Retrieves all web elements found using the XPATH locator.
        Retries are implemented to properly deal with page loading times"""
        elements = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                elements = wd_wait.until(
                    exp_cond.presence_of_all_elements_located(
                        (By.XPATH, xpath)))
                break
            except Exception as exception:
                message = "Unable to find element with xpath: '%s'." \
                          " Retry number: %s out of %s.\n%s"
                logging.info(
                    message, xpath.encode('utf8'), str(i+1), str(retries),
                    exception)
                if (i+1) == retries:
                    raise
        return elements

    def find_element_by_css_selector(self, css, wait=1, retries=4):
        """Retrieves a web element using the CSS selector locator.
        Retries are implemented to properly deal with page loading times"""
        elem = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                elem = wd_wait.until(
                    exp_cond.element_to_be_clickable((By.CSS_SELECTOR, css)))
                break
            except Exception as exception:
                message = "Unable to find element with css selector: '%s'." \
                          " Retry number: %s out of %s.\n%s"
                logging.info(
                    message, css.encode('utf8'), str(i+1), str(retries),
                    exception)
                if (i+1) == retries:
                    raise
        return elem

    def find_elements_by_css_selector(self, css, wait=1, retries=4):
        """Retrieves all web elements found using the CSS SELECTOR locator.
        Retries are implemented to properly deal with page loading times"""
        elements = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                elements = wd_wait.until(
                    exp_cond.presence_of_all_elements_located(
                        (By.CSS_SELECTOR, css)))
                break
            except Exception as exception:
                message = "Unable to find element with css selector: '%s'." \
                          " Retry number: %s out of %s.\n%s"
                logging.info(
                    message, css.encode('utf8'), str(i+1), str(retries),
                    exception)
                if (i+1) == retries:
                    raise
        return elements

    def find_element_by_link_text(self, text, wait=1, retries=4):
        """Retrieves a web element using the LINK TEXT locator.
        Retries are implemented to properly deal with page loading times"""
        elem = None
        for i in range(retries):
            try:
                wd_wait = ui.WebDriverWait(self.driver, int(wait))
                if i % 2 == 0:
                    elem = wd_wait.until(
                        exp_cond.element_to_be_clickable((By.LINK_TEXT, text)))
                else:
                    elem = wd_wait.until(exp_cond.element_to_be_clickable(
                        (By.XPATH, "//a[text()='" + text + "']")))
                break
            except Exception as exception:
                message = "Unable to find element with link text: '%s'." \
                          " Retry number: %s out of %s.\n%s"
                logging.info(
                    message, text, str(i+1), str(retries), exception)
                if (i+1) == retries:
                    raise
        return elem

    def go_to(self, url):
        """Go to the specified url """
        self.driver.get(url)


def click_on_element(elem, wait=1, retries=4):
    """Click on a provided web element.
    Retries are implemented to properly deal with page loading times"""
    for i in range(retries):
        try:
            elem.click()
            break
        except Exception as exception:
            message = "Unable to click element." \
                      " Retry number: %s out of %s.\n%s"
            logging.info(message, str(i+1), str(retries), exception)
            if (i+1) == retries:
                raise
            time.sleep(int(wait))


def execute_step_with_retries(context, step, wait=1, retries=2):
    """Execute a BDD step, retrying the specified number of times
    when an exception arises"""
    for i in range(retries):
        try:
            context.execute_steps(step)
            break
        except Exception as exception:
            message = "The following action could not be performed:" \
                      "\n%s. \nRetry number: %s out of %s.\n%s:"
            logging.info(
                message, step.encode('utf8'), str(i+1), str(retries), exception)
            if (i+1) == retries:
                raise
        time.sleep(int(wait))
