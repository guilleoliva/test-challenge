"""
This module is using for generate_gallery the screenshots in html report
"""
